#ifndef __DIJKSTRA_HPP__
#define __DIJKSTRA_HPP__
#include <vector>
#include "../generator/kruskal.hpp"
using namespace std;
#ifndef pint
#define pint pair<int,int>
#endif


vector<pint> sequential_dijkstra_solver(vector<vector<int>> maze, pint src,pint dest);
vector<pint> distributed_dijkstra_johnson_solver(vector<vector<int>> maze, pint src, pint dest);
#endif

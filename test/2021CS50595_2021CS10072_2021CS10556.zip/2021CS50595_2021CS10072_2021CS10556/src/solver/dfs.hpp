#ifndef __DIJKSTRA__HPP__
#define __DIJKSTRA__HPP__
#include<vector>
using namespace std;
vector<pair<int,int>> sequential_dfs_solve(vector<vector<int>>& maze);
vector<pair<int,int>> parallel_dfs_solver(vector<vector<int>>& maze);

#endif



#include "mazesolver.hpp"
#include "dijkstra.hpp"
#include "dfs.hpp"
#include <cstring>
using namespace std;


vector<pint> solve_maze(char * argv[], maze& maze){
	vector<pint> path;
	if(strcmp(argv[4], "dijkstra") == 0){
		path = distributed_dijkstra_johnson_solver(maze,{0,0},{63,63});
	} else if(strcmp(argv[4],"dfs") == 0){
		path = parallel_dfs_solver(maze);
	}
	return path;
}


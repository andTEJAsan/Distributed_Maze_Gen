#include <iostream>
#include <cassert>
#include <mpi.h>
#include "../generator/bfs.hpp"
#include "../generator/kruskal.hpp"
#include <algorithm>
#include <random>
#include <queue>
using namespace std;
#define infinity INT32_MAX
#ifndef pint
#define pint pair<int,int>
#endif
#ifndef dbg
#define dbg(x) cout << #x << " = " << (x) << "\n";
#endif
#define mpidbg(x) if(me == 1) dbg(x)
#define root 0
vector<pint> adj_m(pint s, int n, const vector<vector<int>>& maze){
	int x = s.first;
	int y = s.second;
	vector<pint> neighbours;
	if(x > 0 && maze[x-1][y] == SPACE) neighbours.push_back(pint {x - 1, y});
	if(x < n - 1 && maze[x+1][y] == SPACE ) neighbours.push_back(pint {x + 1, y});
	if(y > 0 && maze[x][y-1] == SPACE) neighbours.push_back(pint {x, y - 1});
	if(y < n - 1 && maze[x][y+1] == SPACE) neighbours.push_back(pint {x, y + 1});
	return neighbours;
}


vector<pint> sequential_dijkstra_solver(vector<vector<int>> maze, pint src,pint dest){
	// We are going to apply this to a tree, in which there can exist only one path from the source, so we need not worry about relaxation
	int n = maze.size();
	// vector<pint> edges;
	vector<pint> vertices;
	std::random_device rd;
	std::mt19937 g(rd());

	priority_queue<pint, std::vector<pint>, std::greater<pint> > distance; 
	// distance stores (d,(n^2*u + par(u))) for each vertex u represented in integer form
	for(int i = 0 ; i < n*n ; i++){
		if(i == pint_to_int(src,n)){
			distance.push(make_pair(0,n*n*i));
		}
		distance.push(make_pair(infinity, n*n*i ));
	}
	vector<int> parent(n*n,-1);
	parent[pint_to_int(src,n*n)] = pint_to_int(src,n*n);


	// This d[i] will store distance of src from i

	for(int c = 0 ; c < n*n - 1 ; c++ ){
		int min_dist = (distance.top()).first;
		// We will extract all vertices such that d[u] == min_dist in a vector and then do a random shuffle
		vector<int> frontier;
		while(!distance.empty() && (min_dist == distance.top().first)){
			frontier.push_back((distance.top().second));
			distance.pop();
		}
		shuffle(frontier.begin(), frontier.end(), g);
		int v = frontier.back();
		// add the elements  back in the distance queue
		pint p = int_to_pint(v, n*n);
		// edges.push_back(edge(p.first,p.second));
		for(int u : frontier){
			distance.push(make_pair(min_dist, u));
		}

		// All the neighbours of v would have their d value equal to INF would change to  min_dist + 1
		// Actually it doesn't matter, we can simply push min_dist + 1, u to the queue
		for(pint u : adj_m(int_to_pint(int_to_pint(v, n*n).first,n),n,maze)) {
			int int_u = pint_to_int(u,n);
			parent[(int_u)] = int_to_pint(v,n*n).first;
			int int_u_v = pint_to_int(make_pair(int_u, parent[int_u]),n*n) ;
			distance.push( make_pair(min_dist+1, int_u_v));
		}

	}

	int int_u = pint_to_int(dest,n);
	while(int_u != pint_to_int(src,n)){
		dbg(int_u);
		assert(int_u != -1);
		vertices.push_back(int_to_pint(int_u,n));
		int_u = parent[int_u];
	}
	vertices.push_back(src);
	return vertices;
}

vector<pint> distributed_dijkstra_johnson_solver(vector<vector<int>> maze, pint src, pint dest){
	int p = get_total_processors();
	int me = my_rank();
	int n = maze.size();
	vector<int> distance(n*n,infinity);

	vector<int> parent(n*n, 0); 

	priority_queue<pint, vector<pint>, greater<pint>> pq;
	// Priority queue for getting the vertex with the least distance


	if(owner(src,n) == me){
		distance[pint_to_int(src,n)] = 0;
		pq.push({0,pint_to_int(src,n)});
	}

	int sendbuf[3*n*p];
	int recvbuf[3*n*p];

	// Because we have a tree, we don't need to maintain separate tentative queues for d and d's
	MPI_Barrier(MPI_COMM_WORLD);
	while(true){
		int numsendbuf[p] = {0};
		int numrecvbuf[p] = {0};
		if(!pq.empty()){
			pint pair = pq.top(); pq.pop();
			int d_min = pair.first; int int_u = pair.second;
			// distance[int_u] = d_min;
			/*
				for all v adjacent to u 
					w = owner(v)	
					Send (u,v,d_min + 1) To w
				receive messages
				buffer the messages in some buffer
			*/
			for(pint v : adj_m(int_to_pint(int_u, n), n, maze)){
				int w = owner(v, n);
				int idx = 3*n*w + 3*numsendbuf[w];
				sendbuf[idx + 0] = int_u;
				sendbuf[idx + 1] = pint_to_int(v,n);
				sendbuf[idx + 2] = d_min + 1; 
				numsendbuf[w]++;
			}
		}
		// MPI_Alltoall(numsendbuf, 1, MPI_INT,num_recive_buf,  MPI_COMM_WORLD, MPI_INT,);
		MPI_Alltoall(numsendbuf, 1, MPI_INT, numrecvbuf, 1 , MPI_INT, MPI_COMM_WORLD);
		MPI_Alltoall(sendbuf, 3*n, MPI_INT, recvbuf, 3*n, MPI_INT, MPI_COMM_WORLD );
		// We are sending the d values and the parents to each of the processors
		numrecvbuf[me] = numsendbuf[me];
		for(int i = 0 ; i < numsendbuf[me]; i++){
			recvbuf[3*me*n + 3*i] = sendbuf[3*me*n + 3*i];
			recvbuf[3*me*n + 3*i + 1] = sendbuf[3*me*n + 3*i + 1];
			recvbuf[3*me*n + 3*i + 2] = sendbuf[3*me*n + 3*i + 2];
		}

		for(int sender = 0 ; sender < p ; sender++){
			for(int j = 0 ; j < numrecvbuf[sender]; j++){
				int * x = recvbuf + 3*n*sender + 3*j;
				int int_u = x[0];
				int int_v = x[1];
				int d = x[2];
				// We own v.
				// This message only needs to be considered when 
				// distance[v] == INF, no multiple (u1, v) (u2, v) would be there, as the it is a tree
				// No rebalancing needs to be done
				if(distance[int_v] == infinity){
					parent[int_v] = int_u;
					distance[int_v] = d;
					pq.push({d,int_v});
				}

			}
		}
		 
		int sz = pq.size();
		int x = 0; // reduction variable;
		MPI_Allreduce(&sz, &x, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
		if(x == 0){
			break;
		}

	};
	MPI_Barrier(MPI_COMM_WORLD);
	// At this stage parents have been calculated 
	// But the problem is that since the nodes are distributed
	// the correct parents for each of the nodes are present only in 
	// the processor they are owned by. We need to combine all of these entries 
	// to get a final parent array
	// We need a barrier before gathering the Parent vector in the root
	// The parent vector on each of the processors is only valid for the nodes they own
	// i.e, parent[v] is a valid parent only when owner(v) == rank;
	// We will create new p arrays each of size n which are the parent arrays of each of the processors
	// for all v not owned by our processor p, we would multiply 0 to that entry
	// We would then do an allreduce operation on all of the n slots targeted to the root
	// We would need another barrier, to prevent the gather starting before the modified arrays have been 
	// calculated
	// When we do a reduction, we are gauranteed to get a valid parent array because
	// each node is owned exactly by one processor

	for(int i = 0 ; i < n*n; i++){
		if(owner(int_to_pint(i,n),n) != me) parent[i] = 0; // 0 for invalid entries
	}
	int final_parent[n*n];
	// MPI_AllReduce(&(parent[0]), final_parent, n*n, MPI_INT, MPI_SUM, root, MPI_COMM_WORLD);
	MPI_Barrier(MPI_COMM_WORLD);
	MPI_Allreduce((int*) &(parent[0]), final_parent, n*n, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
	// Column wise all reduce operation
	

	// generating the path from parent pointers
	
	vector<pint> path;
	int int_u = pint_to_int(dest,n);
	while(int_u != pint_to_int(src,n)){
		path.push_back(int_to_pint(int_u,n));
		int_u = final_parent[int_u];
	}
	path.push_back(src);

	return path;

}






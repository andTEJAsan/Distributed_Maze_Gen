#include<iostream>
#include<queue>
#include<random>
#include<ctime>
#include <algorithm>
#include <mpi.h>
#include <fstream>
using namespace std;
#define pint pair<int,int>
int cnt = 0;
void print_maze(vector<string> maze)
{
    for(int i = 0; i < maze.size(); i++)
    {
        cout << maze[i] << endl;
    }
}

vector<pint> get_neighbours(pint a, int row_bounds, int col_bounds)
{
    vector<pint> neighbors;
    if(a.first > 0)
        neighbors.push_back(make_pair(a.first-1, a.second));
    if(a.first < row_bounds-1)
        neighbors.push_back(make_pair(a.first+1, a.second));
    if(a.second > 0)
        neighbors.push_back(make_pair(a.first, a.second-1));
    if(a.second < col_bounds-1)
        neighbors.push_back(make_pair(a.first, a.second+1));
    return neighbors;
}

bool DFS(pint cur, vector<vector<pint>> &prev, vector<string> &maze, int maze_size)
{
    //now we get the neighbours of this current node.
    if(maze[cur.first][cur.second] == 'E')
    {
        cout << "REACHED THE END HERE\n";
        return true; //base case.
    }
    cnt += 1;
    maze[cur.first][cur.second] = 'P'; //marking this as visited. //we will remove this P if there is no path from here. 
    vector<pint> neighbours = get_neighbours(cur, maze_size, maze_size);
    for(int i = 0; i < neighbours.size(); i++)
    {
        if(maze[neighbours[i].first][neighbours[i].second] == '*') //this is a wall. 
        {
            continue;
        }
        if(prev[neighbours[i].first][neighbours[i].second] == make_pair(-1,-1)) //haven't visited this neighbour before.
        {
            prev[neighbours[i].first][neighbours[i].second] = cur;
            if(DFS(neighbours[i], prev, maze, maze_size))
                return true; 
        }
    }
    maze[cur.first][cur.second] = ' '; //marking this as visited.
    return false;
}

void DFS_solver(vector<string> &maze)
{
    int maze_size = maze.size();
    vector<vector<pint>> prev(maze_size, vector<pint>(maze_size, {-1,-1}));
    prev[0][0] = {-2,-2};
    maze[0][0] = 'S';
    maze[maze_size-1][maze_size-1] = 'E';
    bool found_path = DFS(make_pair(0,0), prev, maze, maze_size);

    if(!found_path)
    {
        cout << "No path found" << endl;
        // return maze;
    }
    else
    {
        cout << "found a path" << endl;
    }
    maze[0][0] = 'S';
}


int main(int argc, char** argv)
{

    int        comm_sz;               /* Number of processes    */
    int        my_rank;               /* My process rank        */
    MPI_Status status;
    int recv_count;
    MPI_Init(&argc, &argv); 
    MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);  /* Get the number of processes */
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);  /* Get my rank among all the processes */
    //read maze here
    int maze_size = 64;
    vector<string> maze(maze_size);
    if(my_rank == 0)
    {
        ifstream file_maze("maze.txt");
        for(int i = 0; i < maze_size; i++)
        {
            getline(file_maze, maze[i]);
        }
        file_maze.close();
        //now we need to distribute this input to all the processes present.

    }
    if(my_rank == 0)
    {
        DFS_solver(maze);   
        cout << "visited total of " << cnt << " cells" << endl;
        print_maze(maze);
    }
    MPI_Finalize();
    
    //now we have the maze with us.
}
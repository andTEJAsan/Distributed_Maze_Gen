#include <cassert>
#include <iostream> 
#include <fstream> 
#include <sstream> 
#include <string> 
#include <vector> 
#include <queue> 
#include <stack>
#include <algorithm>  
#include <mpi.h> 
#include "../generator/kruskal.hpp"
// #include <dfs.hpp> 

int MAZE_SIZE = 64;
typedef pair<int,int> Cell;
#define ROOT 0


using namespace std;

vector<vector<int>> read_maze(const string& file_path, int n){
    vector<vector<int>> maze;
    std::ifstream file(file_path);

    std::string line;
    for (int i = 0; i < n && std::getline(file, line); ++i) {
        maze.push_back(vector<int> (n,0));
        // cout << "getting line " << i << endl;
        for(int j = 0; j < n; j++){
            if(line[j] == '*'){
                maze[i][j] = 1;
            }
            else if(line[j] == ' '){
                maze[i][j] = 0;
            }
        }
    }
    file.close();

    return maze;
}

void print_maze(vector<vector<int>>& maze){
    for(int i=0; i<maze.size(); i++){
        for(int j=0; j<maze[0].size(); j++){
            if(maze[i][j] == 0) cout << " ";
            else cout << "*";
        }
        cout << endl;
    }
    return;
}



enum Tag {GET_WORK, GIVE_WORK, NO_WORK};

bool is_valid_empty_cell(vector<vector<int>>& maze, int x, int y){
    if (x < 0) return false;
    if (x >= MAZE_SIZE) return false;
    if (y < 0) return false;
    if (y >= MAZE_SIZE) return false;
    // cout << "before segfault" << endl;
    // cout << x << " " << y << endl;
    if (maze[x][y] == 1) return false;
    // cout << "after segfault" << endl;
    return true;
}

vector<Cell> adjacent_list(vector<vector<int>>& maze, Cell c){
    vector<Cell> adj_list;
    int x = c.first;
    int y = c.second;
    if (is_valid_empty_cell(maze, x + 1, y)){
        adj_list.push_back(make_pair(x + 1, y));
    }
    if (is_valid_empty_cell(maze, x, y + 1)){
        adj_list.push_back(make_pair(x, y + 1));
    }
    if (is_valid_empty_cell(maze, x - 1, y)){
        adj_list.push_back(make_pair(x - 1, y));
    }
    if (is_valid_empty_cell(maze, x, y - 1)){
        adj_list.push_back(make_pair(x, y - 1));
    }

    return adj_list;
}

vector<vector<Cell>> prev_cell (MAZE_SIZE, vector<Cell> (MAZE_SIZE, make_pair(-1,-1)));

void solve_maze_dfs(vector<vector<int>>& maze){
    // std::cout << "solving for cell " << curr.first << " " << curr.second << endl;
    // vector<Cell> adj = adjacent_list(maze, curr);
    // if (curr.first == MAZE_SIZE - 1 && curr.second == MAZE_SIZE - 1) {
    //     return;
    // }

    // for(Cell c : adj){
    //     if (c.first == prev.first && c.second == prev.second){
    //         return;
    //     }
    //     else{
    //         prev_cell[c.first][c.second] = curr;
    //         solve_maze_dfs(maze, c, curr);
    //     }
    // }

    stack<pair<Cell,Cell>> frontier;
    frontier.push(make_pair(make_pair(0,0), make_pair(-1,-1)));
    while(!frontier.empty()){
        pair<Cell, Cell> top = frontier.top();
        frontier.pop();
        Cell curr = top.first;
        Cell prev = top.second;
        vector<Cell> adj = adjacent_list(maze, curr);
        for(Cell c : adj){
            if (!(c.first == prev.first && c.second == prev.second)){
                prev_cell[c.first][c.second] = curr;
                frontier.push(make_pair(c, curr));
            }
        }
    }
}

vector<Cell> get_solution(){
    Cell curr = make_pair(MAZE_SIZE - 1, MAZE_SIZE - 1);
    vector<Cell> ans;
    while(curr.first != -1 && curr.second != -1){
        ans.push_back(curr);
        curr = prev_cell[curr.first][curr.second];
    }
    return ans;
}

void print_solved_maze(vector<vector<int>> maze, vector<Cell> solution){

    int n = maze.size();
    for(Cell c : solution){
        maze[c.first][c.second] = PATH;
    }

    maze[0][0] = START;
    maze[n-1][n-1] = END;
    for(int i = 0 ; i < n; i++){
        for(int j = 0 ; j < n; j++){
            cout.flush();
            switch (maze[i][n-1-j])
            {
            case START:
                cout << "S" ;
                break;
            case END:
                cout << "E" ;
                break;
            case WALL:
                cout << "*" ;
                break;
            case SPACE:
                cout << " " ;
                break;
            case PATH :
                cout << "P" ;
                break;
            default:
                assert(false);
                break;
            }
        }
        cout << endl;
    }
}



int cell_to_int(Cell a, int bounds = MAZE_SIZE){
    return a.first*bounds + a.second;
}

Cell int_to_cell(int a, int bounds = MAZE_SIZE){
    return make_pair(a/bounds, a%bounds);
}

// assumes that maze is of dimension 64*64 already
vector<Cell> parallel_dfs_solver(vector<vector<int>>& maze){
    int comm_sz; int rank;
	MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    for(int i = 0; i < MAZE_SIZE; i++){
        MPI_Bcast(&maze[i][0], MAZE_SIZE, MPI_INT, ROOT, MPI_COMM_WORLD);
    }

    // solve_maze_dfs(maze);
    // vector<Cell> solution = get_solution();
    // print_solved_maze(maze, solution);

    vector<vector<Cell>> prev_cell (MAZE_SIZE, vector<Cell> (MAZE_SIZE, make_pair(-1,-1)));
    stack<pair<Cell,Cell>> frontier;

    if(rank == 0){
        frontier.push(make_pair(make_pair(0,0), make_pair(-1,-1)));
    }
    
    int dest_for_getting_work = 0;
    bool waiting_for_work = false;

    while(true){

        // firstly, check the amount of work each process has
        vector<int> work (comm_sz, 0);
        int my_work = frontier.size();

        // gather the work of all processes
        MPI_Allgather(&my_work, 1, MPI_INT, &work[0], 1, MPI_INT, MPI_COMM_WORLD);

        // where should the communication happen in this case
        vector<int>::iterator work_giver = max_element(work.begin(), work.end());
        vector<int>::iterator work_receiver = find(work.begin(), work.end(), 0);

        // if nobody has any work left, return 
        // work is defined as the size of the dfs stack at any moment
        if (*work_giver == 0){
            break;
        }

        // distribute the work
        // by distribution, we mean the process with the highest work pops off one entry
        // and gives this to the process with no work, thus balancing the load
        else if (work_receiver != work.end()){
            int receiver_process = work_receiver - work.begin();
            int sender_process = work_giver - work.begin();

            // for the receiver process
            if (rank == receiver_process){
                int message[4];
                MPI_Status status;
                MPI_Recv(message, 4, MPI_INT, sender_process, 0, MPI_COMM_WORLD, &status);
                frontier.push(make_pair(make_pair(message[0], message[1]), make_pair(message[2], message[3])));
            }

            // for the sender process
            else if (rank == sender_process){
                pair<Cell, Cell> to_send = frontier.top();
                frontier.pop();
                int message[4] = {to_send.first.first, to_send.first.second, to_send.second.first, to_send.second.second};
                MPI_Send(message, 4, MPI_INT, receiver_process, 0, MPI_COMM_WORLD);
            }
        }

        // pop the stack, and push the children of the popped cell
        if(!frontier.empty()){
            // cout << rank << " is doing work" << endl;
            pair<Cell, Cell> top = frontier.top();
            frontier.pop();
            Cell curr = top.first;
            Cell prev = top.second;
            vector<Cell> adj = adjacent_list(maze, curr);
            for(Cell c : adj){
                if (!(c.first == prev.first && c.second == prev.second)){
                    prev_cell[c.first][c.second] = curr;
                    frontier.push(make_pair(c, curr));
                    // cout << "pushing onto stack" << endl;
                    // cout << "size is now " << frontier.size() << endl;
                }
            }
        }

    }

    MPI_Barrier(MPI_COMM_WORLD);

    // share result among processors now 
    // this needs us to convert the data in a suitable format before sending
    vector<vector<int>> prev_in_int_form(MAZE_SIZE, vector<int> (MAZE_SIZE, 0));

    for(int i = 0; i < MAZE_SIZE; i++){
        for(int j = 0; j < MAZE_SIZE; j++){
            prev_in_int_form[i][j] = cell_to_int(prev_cell[i][j]);
        }
    }


    // reduction to get the data of the predecessor of nodes in each process
    int temp;
    vector<vector<Cell>> reduced_prev_cell(MAZE_SIZE, vector<Cell> (MAZE_SIZE, make_pair(-1,-1)));
    for(int i = 0; i < MAZE_SIZE; i++){
        for(int j = 0; j < MAZE_SIZE; j++){
            MPI_Allreduce(&prev_in_int_form[i][j], &temp, 1, MPI_INT, MPI_MAX, MPI_COMM_WORLD);
            reduced_prev_cell[i][j] = int_to_cell(temp);
        }
    }

    // compute the solution as a vector of cells, the cells to be visited on the valid path
    Cell curr = make_pair(MAZE_SIZE - 1, MAZE_SIZE - 1);
    vector<Cell> ans;
    while(curr.first >= 0 && curr.second >= 0){
        // cout << curr.first << " " << curr.second << endl;
        ans.push_back(curr);
        // curr = prev_final[curr.first][curr.second];
        curr = reduced_prev_cell[curr.first][curr.second];
        // cout << curr.first << " " << curr.second << endl;
    }

    return ans;
}


vector<Cell> sequential_dfs_solve(vector<vector<int>>& maze){
    solve_maze_dfs(maze);
    return get_solution();
}
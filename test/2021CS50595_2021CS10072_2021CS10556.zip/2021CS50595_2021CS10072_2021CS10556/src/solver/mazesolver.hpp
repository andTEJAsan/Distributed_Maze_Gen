#ifndef __MAZE_SOLVER__
#define __MAZE_SOLVER__


#include "../generator/mazegenerator.hpp"
#include <vector>
using namespace std;
#ifndef pint
#define pint pair<int,int>
#endif
vector<pint> solve_maze(char * argv[], maze& maze);

#endif


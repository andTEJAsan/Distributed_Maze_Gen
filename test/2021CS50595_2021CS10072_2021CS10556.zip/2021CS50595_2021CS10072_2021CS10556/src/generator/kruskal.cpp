#include<iostream>
#include<queue>
#include<random>
#include<ctime>
#include <algorithm>
#include <mpi.h>
#include <fstream>
#include "bfs.hpp"
#include "kruskal.hpp"
using namespace std;
#ifndef pint
#define pint pair<int,int>
#endif
auto rng = std::default_random_engine {};


class DSU
{
    public:
    vector<int> parents, rank;
    DSU(int n) 
    {
        parents = vector<int>(n,0);
        for (int i = 0; i < n; i++)
        {
            parents[i] = i;
        }
        rank = vector<int>(n,0);
    }

    int get(int a)
    {
        return parents[a] = (parents[a] == a)? a : get(parents[a]); //in this step we set the patent as well as return it.
    }

    void Combine(int a,int b)
    {
        a = get(a); b = get(b);
        if(rank[a] == rank[b])
            rank[a]++; //so there are no ties.
        
        if(rank[a] > rank[b])
        {
            parents[b] = a;
        }
        else
        {
            parents[a] = b;
        }
    }

    bool same(int a, int b)
    {
        return get(a) == get(b);
    }
};

vector<pair<pint, char>> get_neighbours_with_dir(pint a, int bounds)
{
    vector<pair<pint, char>> neighbors;
    if(a.first > 0)
        neighbors.push_back(make_pair(make_pair(a.first-1, a.second), 'R'));
    if(a.first < bounds-1)
        neighbors.push_back(make_pair(make_pair(a.first+1, a.second), 'L'));
    if(a.second > 0)
        neighbors.push_back(make_pair(make_pair(a.first, a.second-1), 'U'));
    if(a.second < bounds-1)
        neighbors.push_back(make_pair(make_pair(a.first, a.second+1), 'D'));
    return neighbors;
}

vector<pint> get_neighbours(pint a, int row_bounds, int col_bounds)
{
    vector<pint> neighbors;
    if(a.first > 0)
        neighbors.push_back(make_pair(a.first-1, a.second));
    if(a.first < row_bounds-1)
        neighbors.push_back(make_pair(a.first+1, a.second));
    if(a.second > 0)
        neighbors.push_back(make_pair(a.first, a.second-1));
    if(a.second < col_bounds-1)
        neighbors.push_back(make_pair(a.first, a.second+1));
    return neighbors;
}

void print_bool_matrix(vector<vector<bool>> mat)
{
    for(int i = 0; i < mat.size(); i++)
    {
        for(int j = 0; j < mat[i].size(); j++)
        {
            cout << (int)mat[i][j] << "";
        }
        cout << endl;
    }

}

void print_maze(vector<string> maze)
{
    for(int i = 0; i < maze.size(); i++)
    {
        cout << maze[i] << endl;
    }
}
vector<string> initialize_maze(int maze_size, char block, char space)
{
    vector<string> maze(maze_size, string(maze_size, block));
    for(int i = 0; i < maze_size; i++)
    {
        for(int j = 0; j < maze_size; j++)
        {
            if(i%2 == 0 && j%2 == 0)
                maze[i][j] = space;
        }
    }
    return maze;

}


vector<string> generate_maze_kruskal(int maze_size, int rank, int total)
{
    //now the n we have is actually half of this.
    int n = maze_size/2;
    char space = ' ';
    char block = '*';
    vector<string> maze = initialize_maze(maze_size, block, space);
    //after initializing we give random weights to each edge.
    DSU dsu(n*n); //dsu for all the n*n cells.
    vector<edge> edges;
    int start_rows = (n/total)*rank;
    int end_rows = (n/total)*(rank+1); 
    int allotted = end_rows - start_rows;
    for(int i = start_rows; i < end_rows; i++)
    {
        for (int j = 0; j < n; j++)
        {
            vector<pint> neighbors = get_neighbours(make_pair(i,j), end_rows,n); //these are all the neighbours.
            for(int k = 0; k < neighbors.size(); k++)
            {
                if(neighbors[k] > make_pair(i,j))
                {
                    edges.push_back(edge(pint_to_int(make_pair(i,j), n), pint_to_int(neighbors[k], n)));
                }
            }
        }
    } 
    //but since the method is supposed to be similar to kruskal, we will use sort().
    // sort(edges.begin(), edges.end(), [](edge a, edge b){return a.weight < b.weight;}); //sorts the edges by weight.
	std::random_device rd;
	std::mt19937 g(rd());
    shuffle(edges.begin(), edges.end(), g);
    //now we start removing the blockages by the sort order.
    int done = 0; int max_removal = allotted*n - 1; //each process only computes values for certain rows. and at the end we join them all.
    for(int i = 0; i < edges.size(); i++)
    {
        if(done >= max_removal)
        {
            break; //finished here.
        }
        int a = edges[i].a;
        int b = edges[i].b;
        if(dsu.same(a,b))
        {
            continue; //then we do not remove this particular edge.
        }
        done++;
        dsu.Combine(a,b);
        //while combining we also need to remove the edge between the two.
        pint a_pint = int_to_pint(a, n);
        pint b_pint = int_to_pint(b, n);
        pint mid = make_pair((a_pint.first + b_pint.first), (a_pint.second + b_pint.second));
        maze[mid.first][mid.second] = space; //opening up this gap.
    }
    maze[maze_size-1][maze_size-1] = space; //opening up the last block.
    maze[maze_size-1][maze_size-2] = space; //opening up the last block.
    // maze[0][maze_size-1] = space; //opening the top right block that will be the entry.
    // maze[maze_size -1][0] = space; //operning the bottom left block that will be the exit.
    return maze;
}

vector<string> distributed_kruskal(int maze_size, int my_rank, int comm_sz)
{
    MPI_Status status;
    srand(time(0)); //sets up the seed for the random number generator. works because we will call this function in difference of seconds.
    // int maze_size = 64;
    vector<string> maze = generate_maze_kruskal(maze_size, my_rank, comm_sz);
    if(my_rank != 0)
    {
        int start_rows = (maze_size/comm_sz)*my_rank;
        int end_rows = (maze_size/comm_sz)*(my_rank+1); 
        for(int i = start_rows; i < end_rows; i++)
        {
            MPI_Send(&maze[i][0], maze_size, MPI_CHAR, 0, 0, MPI_COMM_WORLD);
        }
    }
    else
    {
        for(int i = 1; i < comm_sz; i++)
        {
            int start_rows = (maze_size/comm_sz)*i;
            int end_rows = (maze_size/comm_sz)*(i+1); 
            for(int j = start_rows; j < end_rows; j++)
            {
                char* row = (char*)malloc(maze_size*sizeof(char));
                MPI_Recv(row, maze_size, MPI_CHAR, i, 0, MPI_COMM_WORLD, &status);
                maze[j] = string(row); //setting the rows of the maze.
            }
        }
        //now we need to open an entryway from each of the 4 sections to each other.
        vector<int> rows_to_open = {maze_size/4 - 1, maze_size/2 - 1, (3*maze_size)/4 - 1};
        for(auto row : rows_to_open)
        {
            vector<int> possible_openings;
            for(int i = 0; i < maze_size; i++)
            {
                if(maze[row+1][i] == ' ' && maze[row-1][i] == ' ') //finding a position where both the above and below have open positions.
                {
                    possible_openings.push_back(i);
                }
            }
            if(possible_openings.size() == 0)
            {
                cout << "no opening found" << endl; //case will never happen actually.
            }
            int opening = possible_openings[rand()%possible_openings.size()];
            maze[row][opening] = ' ';
            // cout << "opening at row: " << row << " column: " << opening << endl;
        }
        //print_maze(maze);
        // return maze;
        
    }
    //after this what we need to do is simply send the generated maze to all instances so they all return the same maze.
    for(int row = 0; row < maze_size; row++)
    {
        MPI_Bcast(&maze[row][0], maze_size, MPI_CHAR, 0, MPI_COMM_WORLD); //broadcasts the generated maze to all.
    }
    //NOW, all the processors have the complete maze with them. 
    return maze;
}


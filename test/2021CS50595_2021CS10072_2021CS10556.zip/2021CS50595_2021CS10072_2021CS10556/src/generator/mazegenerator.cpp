#include <cstring>
#include "mazegenerator.hpp"
#include "bfs.hpp"
#include "kruskal.hpp"
#include <mpi.h>
#include <vector>
#include <cassert>
#include <string>
using namespace std;


void generate_maze(char * argv[], maze& maze ){
	int rank = my_rank();
	int comm_sz = get_total_processors();
	vector<edge>  t;
	if(strcmp(argv[2], "bfs") == 0){
		t = distributed_bfs(32, {0,0});
		maze = tree_to_grid(t);
	} else if(strcmp(argv[2], "kruskal") == 0){
		// auto temp = complete_maze_kruskal(64,rank,comm_sz);
		vector<string> temp = distributed_kruskal(64,rank, comm_sz);
		maze.resize(64);
		for(auto & x : maze) x.resize(64);
		for(int i = 0 ; i < 64; i++){
			for(int j= 0 ; j < 64; j++){
				if(temp[i][j] == '*'){
					maze[i][j] = 1;
				} else if(temp[i][j] = ' '){
					maze[i][j] = 0;
				} else {
					assert(false);
				}
			}
		}
	}
}
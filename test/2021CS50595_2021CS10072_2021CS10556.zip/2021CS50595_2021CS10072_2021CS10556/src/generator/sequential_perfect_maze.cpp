#include<iostream>
#include<queue>
#include<random>
#include<ctime>
#include <algorithm>
#include <fstream>
#include <vector>
#include <string>
#include <utility>
#include <thread>
#include <chrono>

using namespace std;
#define pint pair<int,int>
// int INTMAX = 1e8; //taking a very high number for no connections.

double sleep_time = 0.1;


auto rng = std::default_random_engine {};
struct edge
{
    int a;
    int b;
    int weight;
    edge(int a, int b)
    {
        this->a = a;
        this->b = b;
        this->weight = 0;
    }
    edge(int a, int b, int weight)
    {
        this->a = a;
        this->b = b;
        this->weight = weight;
    }
};

int pint_to_int(pint a, int bounds)
{
    return a.first*bounds + a.second;
}
pint int_to_pint(int a, int bounds)
{
    return make_pair(a/bounds, a%bounds);
}

class DSU
{
    public:
    vector<int> parents, rank;
    DSU(int n) 
    {
        parents = vector<int>(n,0);
        for (int i = 0; i < n; i++)
        {
            parents[i] = i;
        }
        rank = vector<int>(n,0);
    }

    int get(int a)
    {
        return parents[a] = (parents[a] == a)? a : get(parents[a]); //in this step we set the patent as well as return it.
    }

    void Combine(int a,int b)
    {
        a = get(a); b = get(b);
        if(rank[a] == rank[b])
            rank[a]++; //so there are no ties.
        
        if(rank[a] > rank[b])
        {
            parents[b] = a;
        }
        else
        {
            parents[a] = b;
        }
    }

    bool same(int a, int b)
    {
        return get(a) == get(b);
    }
};

vector<pair<pint, char>> get_neighbours_with_dir(pint a, int bounds)
{
    vector<pair<pint, char>> neighbors;
    if(a.first > 0)
        neighbors.push_back(make_pair(make_pair(a.first-1, a.second), 'R'));
    if(a.first < bounds-1)
        neighbors.push_back(make_pair(make_pair(a.first+1, a.second), 'L'));
    if(a.second > 0)
        neighbors.push_back(make_pair(make_pair(a.first, a.second-1), 'U'));
    if(a.second < bounds-1)
        neighbors.push_back(make_pair(make_pair(a.first, a.second+1), 'D'));
    return neighbors;
}

vector<pint> get_neighbours(pint a, int bounds)
{
    vector<pint> neighbors;
    if(a.first > 0)
        neighbors.push_back(make_pair(a.first-1, a.second));
    if(a.first < bounds-1)
        neighbors.push_back(make_pair(a.first+1, a.second));
    if(a.second > 0)
        neighbors.push_back(make_pair(a.first, a.second-1));
    if(a.second < bounds-1)
        neighbors.push_back(make_pair(a.first, a.second+1));
    return neighbors;
}

void print_bool_matrix(vector<vector<bool>> mat)
{
    for(int i = 0; i < mat.size(); i++)
    {
        for(int j = 0; j < mat[i].size(); j++)
        {
            cout << (int)mat[i][j] << "";
        }
        cout << endl;
    }

}

void print_maze(vector<string> maze)
{
    for(int i = 0; i < maze.size(); i++)
    {
        cout << maze[i] << endl;
    }
}
vector<string> initialize_maze(int maze_size, char block, char space)
{
    vector<string> maze(maze_size, string(maze_size, block));
    for(int i = 0; i < maze_size; i++)
    {
        for(int j = 0; j < maze_size; j++)
        {
            if(i%2 == 0 && j%2 == 0)
                maze[i][j] = space;
        }
    }
    return maze;

}

void output_maze(vector<string> maze)
{
    ofstream file;
    file.open("maze.txt");
    for(int i = 0; i < maze.size(); i++)
    {
        file << maze[i] << endl;
    }
    file.close();
}

vector<string> generate_maze_kruskal(int maze_size)
{
    //now the n we have is actually half of this.
    int n = maze_size/2;
    char space = ' ';
    char block = '*';
    vector<string> maze = initialize_maze(maze_size, block, space);
    //after initializing we give random weights to each edge.
    DSU dsu(n*n); //dsu for all the n*n cells.
    vector<edge> edges;
    for(int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            vector<pint> neighbors = get_neighbours(make_pair(i,j), n); //these are all the neighbours.
            for(int k = 0; k < neighbors.size(); k++)
            {
                if(neighbors[k] > make_pair(i,j))
                {
                    edges.push_back(edge(pint_to_int(make_pair(i,j), n), pint_to_int(neighbors[k], n), rand()));
                }
            }
        }
    } 

    //after this we have this vector of edges. all that we need to do now is to shuffle them. we can use sort for this, or we can do a random shuffle. 
    //but since the method is supposed to be similar to kruskal, we will use sort().
    sort(edges.begin(), edges.end(), [](edge a, edge b){return a.weight < b.weight;}); //sorts the edges by weight.
    //now we start removing the blockages by the sort order.
    int done = 0; int max_removal = n*n - 1;
    for(int i = 0; i < edges.size(); i++)
    {
        if(done >= max_removal)
        {
            break; //finished here.
        }
        int a = edges[i].a;
        int b = edges[i].b;
        if(dsu.same(a,b))
        {
            continue; //then we do not remove this particular edge.
        }
        done++;
        dsu.Combine(a,b);
        //while combining we also need to remove the edge between the two.
        pint a_pint = int_to_pint(a, n);
        pint b_pint = int_to_pint(b, n);
        pint mid = make_pair((a_pint.first + b_pint.first), (a_pint.second + b_pint.second));
        maze[mid.first][mid.second] = space; //opening up this gap.
        //now we print the maze to the file.
        output_maze(maze); //for step by step display.
        this_thread::sleep_for(chrono::milliseconds(50)); //sleeping for 100 milliseconds before the next output.
    }
    maze[maze_size-1][maze_size-1] = space; //opening up the last block.
    maze[maze_size-1][maze_size-2] = space; //opening up the last block.
    return maze;
}

int main(int argc, char* argv[])
{
    srand(time(0)); //sets up the seed for the random number generator. works because we will call this function in difference of seconds.
    int maze_size = 32;
    vector<string> maze = generate_maze_kruskal(maze_size);
    print_maze(maze);
}
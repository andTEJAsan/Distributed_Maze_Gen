#ifndef __MAZE_GENERATOR__
#define __MAZE_GENERATOR__
#include<vector>
using namespace std;

typedef vector<vector<int>> maze;

void generate_maze(
/* in */	char * argv[],
/* out */	maze& maze
);



#endif
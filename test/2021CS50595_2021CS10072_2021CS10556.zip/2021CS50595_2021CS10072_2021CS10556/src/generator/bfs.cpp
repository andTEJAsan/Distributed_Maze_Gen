#include<iostream>
#include<vector>
#include "bfs.hpp"
#include "kruskal.hpp"
#include <math.h>
#include<cassert>
#include <queue>
#include <algorithm>
#include <mpi.h>
#include <random>
using namespace std;

#define pint std::pair<int,int>
#ifndef dbg
#define dbg(x) cout << #x << " = " << (x) << "\n";
#endif
#define mpidbg(x) if(me == 0) dbg(x)
#define barrier MPI_Barrier(MPI_COMM_WORLD)
/*
	REPRESENTATION DECISIONS
	THE GRAPH is represented implicitly for each n, because we know for each cell i,j 
	its neighbours are i-1,j i+1,j i,j-1 i,j+1

	Each vertex can be represented by either (i,j) -> pair<int,int> or n*i + j (int)
	We have conversion funcitons for the conversions

	the 'edge' datatype is consisting of a, b where a and b are endpoints represented as ints

	For each non-tree edge, there must be a well between the vertices in the grid.

	So we create an MST on a grid of size n/2 x n/2
	Then we create a grid of size n x n with odd numbered positions blocked
	We expand the MST to our grid, and for each edge present in the MST,
	We remove the wall between them to maintain the connectivity. 
*/


vector<pint> adj(pint s, int n){
	int x = s.first;
	int y = s.second;
	vector<pint> neighbours;
	if(x > 0) neighbours.push_back(pint {x - 1, y});
	if(x < n - 1) neighbours.push_back(pint {x + 1, y});
	if(y > 0) neighbours.push_back(pint {x, y - 1});
	if(y < n - 1) neighbours.push_back(pint {x, y + 1});
	return neighbours;
}




vector<edge> sequential_bfs(int grid_size, pint src){
	// INPUT: G=(V,E) implicitly through grid_size
	// src = (x,y) starting vertex
	// OUTPUT: List of edges in the BFS tree
	vector<edge> edges;
	std::random_device rd;
	std::mt19937 g(rd());

	int n = grid_size;
	vector<int> visited(n*n, 0); // visited array for each of the n x n nodes (in integer form)
	visited[pint_to_int(src, n)] = -1; // mark src visited
	// visited = -1 means in the frontier
	// visited = 1 means visited
	// visited = 0 means not visited

	vector<pint> front; // Queue of vertices
	front.push_back(src);

	while(!front.empty()){
		// pint u = q.front(); q.pop();

		vector<pint> next_front;	
		for(pint u : front){
			// mark u visited
			// dbg(pint_to_int(u,n));
			if(visited[pint_to_int(u,n)] == 1) continue;
			visited[pint_to_int(u,n)] = 1;
			for(pint v : adj(u,n)) {
				// for all unvisited neighbours of u, add them in the list of edges
				if(visited[pint_to_int(v,n)] == 0){
					// q.push(v);
					visited[pint_to_int(v,n)] = -1;
					// this is done to prevent 2 nodes in the frontier 
					// having a common neighbour 
					// so both we mark the common neighbour as 2
					// so that we dont visit it again
					
					
					// if we don't do this we can add multiple edges with the same 
					// next frontier end point 
					next_front.push_back(v);
					int int_u = pint_to_int(u,n);
					int int_v = pint_to_int(v,n);
					edges.push_back(edge(int_u,int_v));
				}
			}
		}
		// cout << " next front = ";
		// for(pint u : next_front){
		// 	cout << "(" << u.first << "," << u.second << ")";
		// }
		// for(edge e : edges){
		// 	cout << "edge " << e.a << " " << e.b << "\n";
		// }
		// cout << "\n";
		std::shuffle(next_front.begin(), next_front.end(), g);
		front = next_front;
	}
	cout << edges.size() << " edge size" << "\n";
	cout << grid_size << " grdi size" << "\n";
	cout << grid_size*grid_size - 1 << "\n";
	return edges;
}


int get_total_processors(void){
	int comm_sz;
	MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
	return comm_sz;
}
int my_rank(void){
	int rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	return rank;
}

int owner(pint vertex, int n){
	// we divide the vertices among p processors column wise
	int p = get_total_processors();
	return vertex.second % p; 
}
void int_edge_to_vector(int * edges, int sz, int n){
	vector<edge> es;
	cout << "begin\n";
	for(int i =0 ; i < sz; i++){
		int int_u = edges[i] / (n*n);
		int int_v = edges[i] % (n*n);
		cout << "(" << int_u << "," << int_v << ")" << "\n";
	}
	cout << "end\n";
}
vector<edge> distributed_bfs(int grid_size, pint src){
	// INPUT: G=(V,E) implicitly through grid_size
	// src = (x,y) starting vertex
	// OUTPUT: List of edges in the BFS tree
	int root = 0;
	int me = my_rank();
	int p = get_total_processors();
	int n = grid_size;
	int edges[2*n*(n-1)]; // no of edges in a connected grid
	int num_edges = 0;
	std::random_device rd;
	std::mt19937 g(rd());
	// Mersenne Twister Random seed

	vector<int> visited(n*n, 0); // visited array for each of the n x n nodes (in integer form)

	vector<pint> front; // Queue of vertices owned by me
	if(owner(src, n) == me){
		// If I am the owner of src
		visited[pint_to_int(src, n)] = 1;
		front.push_back(src);
	}
	int sendbuff[n*p]; // buffer for message passing
	int recvbuff[n*p];

	while(true){
		// pint u = q.front(); q.pop();
		vector<pint> next_front;	
		MPI_Barrier(MPI_COMM_WORLD);

		int length_sendbuf[p] = {0};
		int length_recvbuf[p] = {0};
		// length_sendbuf[i] is the amount of data we are going to send later to processor i
		/*
			for each u in frontier:
				for v in neighbours(u):
				w = owner(v)	// w will check if it is visited or not and add to the frontier accordingly
				we would send (v,u) as n^2*v + u to each processor
				int_v < n^2 
		*/

		for(pint u : front){
			visited[pint_to_int(u,n)] = 1;
			for(pint v : adj(u,n)) {
				int w = owner(v,n);
				sendbuff[w*n + length_sendbuf[w]] = n*n*pint_to_int(v,n) + pint_to_int(u,n);
				length_sendbuf[w]++;
			}
		}
		
		// We receive all the buffers supposed to be for us  and every other processor does so too
		MPI_Alltoall(length_sendbuf,1, MPI_INT, length_recvbuf, 1, MPI_INT, MPI_COMM_WORLD);
		MPI_Alltoall(sendbuff, n, MPI_INT, recvbuff, n, MPI_INT, MPI_COMM_WORLD);

		// iterate over all other processors and combine to get the next frontier
		// at first only removing visited nodes, then while getting edges we will filter out 
		// nodes having common parents as well to deal with duplicates

		length_recvbuf[me] = length_sendbuf[me];
		for(int i = 0 ; i < length_recvbuf[me]; i++){
			// assert(me*n + i < n*p);
			recvbuff[me*n + i] = sendbuff[me*n + i];
		}


		// Read the received messages
		vector<pint> unvisited_next_frontier; // (v,u) where u was the node in the previous frontier
		for(int sender = 0; sender < p ; sender++){
			for(int i = 0; i < length_recvbuf[sender]; i++){
				// We received (v,u) as n^2*int_v + int_u so extracting v and u
				int int_v = recvbuff[sender*n + i] / (n*n);
				int int_u = recvbuff[sender*n + i] % (n*n);

				// We own the vertex v only. So the visited[v] is valid
				// We push into our local frontier if visited[v] is false

				if(visited[int_v] == 0){
					unvisited_next_frontier.push_back(make_pair(int_v,int_u));
				}
			}
		}
		shuffle(unvisited_next_frontier.begin(), unvisited_next_frontier.end(), g); 
		// For randomization
		// Ensuring those vertices which had multiple parents don't get counted multiple times
		for(int i = 0 ; i < unvisited_next_frontier.size(); i++){
			int int_v = unvisited_next_frontier[i].first;
			int int_u = unvisited_next_frontier[i].second;
			if(visited[int_v] == 0){
				visited[int_v] = -1; // so that this doesn't get repeated by any other int_u
				// we own int_v
				next_front.push_back(int_to_pint(int_v,n));
				// edges.push_back(edge(int_u,int_v));
				edges[num_edges] = pint_to_int(make_pair(int_u,int_v), n*n);
				num_edges++;
				// for(int i = 0 ; i < num_edges; i++){
				// 	assert(edges[i] !=  pint_to_int(make_pair(int_u,int_v), n*n));
				// }
			}

		}
		int size = next_front.size();
		int redsize;
		MPI_Allreduce(&size, &redsize, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);
		if(redsize == 0){
			break;
		}
		front = next_front;
	}
	MPI_Barrier(MPI_COMM_WORLD);
	// Now we need to gather all the tree edges using allgatherv
	// first we need to gather the number of edges that need to be gathered from each processor
	int num_edges_buf[p] = {0};
	// MPI_Gather(&num_edges,1, MPI_INT, num_edges_buf, 1, MPI_INT, root , MPI_COMM_WORLD);
	// We will gather how many edges we are going to collect from each processor
	MPI_Allgather(&num_edges, 1, MPI_INT, num_edges_buf, 1, MPI_INT, MPI_COMM_WORLD);
	num_edges_buf[me] = num_edges;
	// Builds the displacements array
	int num_edges_displs[p] = {0};
	for(int i = 0,sum = 0 ; i < p; i++){
		num_edges_displs[i] = sum;
		sum += num_edges_buf[i];
	}

	int final_edges[num_edges_displs[p-1] + num_edges_buf[p-1]];
	// MPI_Gatherv(edges, num_edges, MPI_INT, final_edges, num_edges_buf,num_edges_displs, MPI_INT, root, MPI_COMM_WORLD );

	// MPI_Allgatherv -> Stands for all gather vector used for all gather of variable lengths
	// For eg each processor is going to send variable amounts of data to every other processor
	MPI_Allgatherv(edges, num_edges, MPI_INT, final_edges, num_edges_buf,num_edges_displs,MPI_INT, MPI_COMM_WORLD );
	vector<edge> final_edges_v;

	for(int i = 0 ; i < p ; i++){
		for(int j = 0 ; j < num_edges_buf[i]; j++){
			int e = final_edges[num_edges_displs[i] + j];
			int int_u = e / (n*n);
			int int_v = e % (n*n);
			final_edges_v.push_back(edge(int_u,int_v));
		}
	}
	MPI_Barrier(MPI_COMM_WORLD);
	// every processor has the minimmum spanning tree now
	return final_edges_v;
}











int isqrt(int x){
	int y = 1;
	while(y*y < x) y <<= 1;
	y >>= 1;
	int l = y;
	int r = 2*y;
	while(l < r){
		int mid = l + (r - l)/ 2;
		if(mid*mid < x) l = mid + 1;
		else r = mid;
	}
	if(l*l != x){
		cout << l << ' ' << x << "\n";
		cout << "Error" << "\n";
	}
	return l;

}
int pint_to_int(pint a, int bounds)
{
    return a.first*bounds + a.second;
}
pint int_to_pint(int a, int bounds)
{
    return make_pair(a/bounds, a%bounds);
}




vector<vector<int>> tree_to_grid(vector<edge> e){

	// converts the MST to a grid with walls
	// the size of the grid would be twice the size of MST grid
	// dbg(e.size());
	int n = isqrt(1 + e.size());

	vector<vector<int>> grid(2*n, vector<int>(2*n));
	// 1 means blocked 0 means free 
	for(int i = 1; i < 2*n; i+= 2){
		for(int j = 0; j < 2*n; j++) grid[i][j] = 1;
	}
	for(int i = 1; i < 2*n; i+= 2){
		for(int j = 0; j < 2*n; j++) grid[j][i] = 1;
	}
	// grid[2*n-2][2*n-1] = 0;
	grid[2*n-1][2*n-2] = 0;
	grid[2*n-1][2*n-1] = 0;

	for(edge edge : e){
		pint p1 = int_to_pint(edge.a, n);		
		pint p2 = int_to_pint(edge.b, n);
		int x1 = p1.first; int y1 = p1.second; int x2 = p2.first; int y2 = p2.second;
		grid[x1+x2][y1+y2] = 0;
	}
	return grid;
}

void print_grid(vector<vector<int>> g){
	int n = g.size();
	for(int i = 0 ; i < n; i++){
		for(int j = 0; j < n; j++){
			if(g[i][j]) cout << "*";
			else cout << " ";
		}
		cout << "\n";
	}
}



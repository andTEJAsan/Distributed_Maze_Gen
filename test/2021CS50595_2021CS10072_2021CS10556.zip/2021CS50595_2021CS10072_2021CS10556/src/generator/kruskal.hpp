#ifndef KRUSKAL_HPP
#define KRUSKAL_HPP
#include <utility>
#include <string>
using namespace std;
enum CellState {SPACE, WALL,START,END,PATH};
struct edge
{
    int a;
    int b;
    int weight;
    edge(int a, int b)
    {
        this->a = a;
        this->b = b;
        this->weight = 0;
    }
    edge(int a, int b, int weight)
    {
        this->a = a;
        this->b = b;
        this->weight = weight;
    }
};
vector<string> distributed_kruskal(int maze_size, int my_rank, int comm_sz);
#endif

#ifndef BFS
#define BFS
#include <vector>
#include "kruskal.hpp"
#define pint std::pair<int,int>

using namespace std;

void print_grid(vector<vector<int>> g );
vector<vector<int>> tree_to_grid(vector<edge> e);
int pint_to_int(pint a, int bounds);
pint int_to_pint(int a, int bounds);
int isqrt(int x);
vector<edge> sequential_bfs(int grid_size, pint src);
vector<edge> distributed_bfs(int grid_size, pint src);
void print_solved_maze(vector<vector<int>> maze, vector<pint> path);
vector<pint> adj(pint s, int n);
int my_rank(void);
int owner(pint vertex, int n);
int get_total_processors(void);
int rotate_maze(vector<int> );

#endif 
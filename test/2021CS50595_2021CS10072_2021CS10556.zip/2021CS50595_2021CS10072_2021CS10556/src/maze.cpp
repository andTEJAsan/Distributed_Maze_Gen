#include<cstring>
#include<cassert>
#include<iostream>
#include<mpi.h>
using namespace std;
#include "generator/bfs.hpp"
#include "generator/kruskal.hpp"
#include "solver/dfs.hpp"
#include "solver/dijkstra.hpp"
#include "generator/mazegenerator.hpp"
#include "solver/mazesolver.hpp"



#define dbg(x) cout << #x << " = " << (x) << "\n";
#ifndef pint
#define pint pair<int,int>
#endif
#define node pint
#define barrier MPI_Barrier(MPI_COMM_WORLD)
int main(int argc, char* argv[]) {
	int comm_sz; int rank;
	MPI_Init(NULL,NULL);

	MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	



	MPI_Barrier(MPI_COMM_WORLD);
	maze g;
	generate_maze(argv, g); // This will be called simultaneously on all processors
	// if(rank == 0){
	// 	print_grid(g);
	// }	

	cout.flush();
	

	MPI_Barrier(MPI_COMM_WORLD);
	// Every processor should have the generated maze before they start solving it
	// vector<node> path;
	vector<node> path = solve_maze(argv, g);


	// print the solved maze from processor 0
	if(rank == 0){
		print_solved_maze(g,path);
	}


	MPI_Finalize();
	return 0;
}


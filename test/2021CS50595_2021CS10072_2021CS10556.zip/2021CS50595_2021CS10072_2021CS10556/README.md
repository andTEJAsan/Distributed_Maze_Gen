## MPI Maze generation and solving.

I (Dhruv) will handle the kruskal generation and DFS solution algorithms.
Tejas please work on the rest (BFS generation and Djikstra solving) with mpi.

I have DL assignment as well whose deadline is on 6th so I won't be able to do much aside from these. I can work on the report of what I did on 7th before submission.

tis easy so finish it quicc
